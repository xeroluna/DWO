<?php
$host           = "localhost";
$user           = "root";
$password       = "";
$database       = "adventuresales";
$conn = mysqli_connect($host, $user, $password, $database);
$connect = $conn;
