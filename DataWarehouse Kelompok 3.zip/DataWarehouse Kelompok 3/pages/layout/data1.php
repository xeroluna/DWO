<?php
require('koneksi.php');

$sql1 = "SELECT d.bulan as bulan, d.tahun as tahun , sum(f.OrderQty) as order_perbulan
from adventurepurchase.dimdate d 
join adventurepurchase.factpurchase f on d.TimeID = f.TimeID 
group by d.bulan, d.tahun 
order by d.tahun, (0+d.bulan) 
";

$result1 = mysqli_query($conn,$sql1);

$pendapatan = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "order_perbulan"=>$row['order_perbulan'],
        "bulan" => $row['bulan'],
        "tahun" => $row['tahun']
    ));
}

$data1 = json_encode($pendapatan);
?>