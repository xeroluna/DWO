<?php
$host = 'localhost';
$db = 'adventurepurchase';
$user = 'root';
$pass = '';

$connection = mysqli_connect($host, $user, $pass, $db);
$sql1 = "SELECT f.Name as kategori, 
       SUM(p.OrderQty) AS total,
       (SUM(p.OrderQty)/(SELECT SUM(OrderQty) FROM factpurchase)) * 100 AS 'persentase'
       FROM dimvendor f, factpurchase p 
       WHERE f.VendorID = p.VendorID GROUP BY f.Name 
";

$result = mysqli_query($connection,$sql1);

$hasil = array();

while ($row = mysqli_fetch_array($result)) {
    array_push($hasil,array(
        "name"=>$row['kategori'],
        "total"=>$row['total'],
        "y"=>$row['persentase']
    ));
}

$data7 = json_encode($hasil);

?>