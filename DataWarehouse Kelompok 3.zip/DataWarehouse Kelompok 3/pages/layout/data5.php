<?php
$host = 'localhost';
$db = 'adventuresales';
$user = 'root';
$pass = '';

$connection = mysqli_connect($host, $user, $pass, $db);
// get persentase kategori
$sqlKategori = 'SELECT f.territoryname, 
       SUM(p.LineTotal) AS total,
       (SUM(p.LineTotal)/(SELECT SUM(LineTotal) FROM factsale)) * 100 AS "persentase"
       FROM dimcustomer f, factsale p 
       WHERE f.CustomerID = p.CustomerID GROUP BY f.territoryname';
$resultKategori = mysqli_query($connection, $sqlKategori);
$dataKategori = [];
$objectKategori = array();
while($row = mysqli_fetch_all($resultKategori)){
    $dataKategori[] = $row;
}

foreach ($dataKategori[0] as $row){

    $objectKategori[] = array(
        'name' => $row[0],
        'y' =>$row[1],
        'drilldown' => $row[0]
    );
}

$jsonKategori = json_encode($objectKategori, JSON_NUMERIC_CHECK);
//$jsonKategori = preg_replace('/"([a-zA-Z]+[a-zA-Z0-9_]*)":/','$1:',$jsonKategori);

?>