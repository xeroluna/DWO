<?php
require('koneksi.php');

$sql1 = "SELECT d.bulan as bulan , d.tahun as tahun, sum(f.LineTotal) as Total_perbulan
from  adventurepurchase.dimdate d 
join adventurepurchase.factpurchase f on d.TimeID =f.TimeID
where d.tahun = '2004'
group by d.bulan
order by d.tahun, (0+d.bulan)
";

$result1 = mysqli_query($conn,$sql1);

$pendapatan = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "Total_perbulan"=>$row['Total_perbulan'],
        "bulan" => $row['bulan'],
        "tahun" => $row['tahun']
    ));
}

$data2 = json_encode($pendapatan);
?>