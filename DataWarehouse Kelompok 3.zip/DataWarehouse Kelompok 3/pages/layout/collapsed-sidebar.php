<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Boxed Layout</title>

 <!-- Sidebar -->
        <?php include "sidebar.php";?>
        <!-- End of Sidebar -->

  <!-- main -->
        <?php
        include "data2.php";
$data2 = json_decode($data2, TRUE);
?>

 <figure class="highcharts-figure">
    <div id="container"></div>
    <p class="highcharts-description"></p>
</figure>
<script type="text/javascript">
        //create linechart
        Highcharts.chart('container', {
            chart: {
                type: 'column'
            },
            title: {
                text: 'Line total tertinggi selama produksi 2004'
            },
            subtitle: {
                text: 'Source: Database AdventureWorks'
            },
            xAxis: {
                categories: [
                    <?php for ($i=0; $i < count($data2); $i++):?>
                        <?= $data2[$i]["bulan"]; ?>,
                    <?php endfor;?>
                ]
            },
            yAxis: {
                title: {
                    text: 'Banyaknya pembelian'
                }
            },
            plotOptions: {
                line: {
                    dataLabels: {
                        enabled: true
                    },
                    enableMouseTracking: false
                }
            },
            series: [
                <?php for ($i=0; $i < count($data2); $i+=9):?>
                {
                name: '<?= $data2[$i]["tahun"]; ?>',
                data: [
                    <?php for ($a=$i; $a < $i+9; $a++):?>
                        <?= $data2[$a]["Total_perbulan"]; ?>,
                    <?php endfor;?>
                    ]
                },
                <?php endfor;?>
            ]
        });
</script>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                Source : AdventureSales
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.2.0
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="../../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
</body>
</html>