<?php
require('koneksi.php');

$sql1 = "SELECT f.category kategori, 
        t.bulan as bulan,
       COUNT(fp.ProductID) as pendapatan 
    FROM dimproduk f, factsale fp, dimdate t 
WHERE (f.ProductID= fp.ProductID) AND (t.TimeID = fp.TimeID)
GROUP BY kategori, bulan
order by kategori, (0+bulan)";

$result1 = mysqli_query($conn,$sql1);

$pendapatan = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "pendapatan"=>$row['pendapatan'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}

$data3full = json_encode($pendapatan);

?>