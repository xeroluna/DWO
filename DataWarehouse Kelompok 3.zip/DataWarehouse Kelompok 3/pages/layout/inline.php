<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>AdminLTE 3 | Boxed Layout</title>

 <!-- Sidebar -->
        <?php include "sidebar.php";?>
        <!-- End of Sidebar -->

  <!-- main -->
      <?php 
//data barchart
include 'data7.php';
include 'data8.php';

$data7 = json_decode($data7, TRUE);
$data8 = json_decode($data8, TRUE);
?>

 <figure class="highcharts-figure">
    <div id="container"></div>
    <p class="highcharts-description"></p>
</figure>
<script type="text/javascript">
        //create linechart
        Highcharts.chart('container', {
            chart: {
                type: 'pie'
            },
            title: {
                text: 'Data Pendapatan dari Setiap Kategori'
            },
            subtitle: {
                text: 'Source: Database WHSakila2021'
            },
        
            accessibility: {
                announceNewData: {
                    enabled: true
                },
                point: {
                    valueSuffix: '%'
                }
            },
        
            plotOptions: {
                series: {
                    dataLabels: {
                        enabled: true,
                        format: '{point.name}: {point.y:.1f}%'
                    }
                }
            },
        
            tooltip: {
                headerFormat: '<span style="font-size:11px">{series.name}</span><br>',
                pointFormat: '<span style="color:{point.color}">{point.name}</span>: <b>{point.y:.2f}%</b> of total<br/>'
            },
        
            series: [
                {
                    name: "Kategori",
                    colorByPoint: true,
                    data: [
                        <?php foreach ($data7 as $data):?>
                        {
                            name: '<?= $data["name"]; ?>',
                            y: <?= $data["y"]; ?>,
                            drilldown: '<?= $data["name"]; ?>'
                        },
                        <?php endforeach;?>
                    ]
                }
            ],
            drilldown: {
                series: [
                    <?php for ($i=0; $i < count($data8); $i+=70):?>
                    {
                        name: "<?= $data8[$i]["kategori"]; ?>",
                        id: "<?= $data8[$i]["kategori"]; ?>",
                        data: [
                            <?php for ($a=$i; $a < $i+70; $a++):?>
                            [
                                "<?= $data8[$a]["bulan"]; ?>",
                                <?= floatval($data8[$a]["persen"]); ?>
                            ],
                            <?php endfor;?>
                        ]
                    },
                    <?php endfor;?>
                ]}
        });
</script>
              </div>
              <!-- /.card-body -->
              <div class="card-footer">
                Source : AdventureSales
              </div>
              <!-- /.card-footer-->
            </div>
            <!-- /.card -->
          </div>
        </div>
      </div>
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.2.0
    </div>
    <strong>Copyright &copy; 2014-2021 <a href="https://adminlte.io">AdminLTE.io</a>.</strong> All rights reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="../../plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
</body>
</html>