<?php
require('koneksi.php');

$sql1 = "SELECT f.territoryname kategori, 
        t.tahun as bulan,
       sum(fp.LineTotal) as pendapatan 
       from dimcustomer f
       join factsale fp on f.CustomerID = fp.CustomerID 
       join dimdate t on t.TimeID = fp.TimeID 
       group by f.territoryname, t.tahun 
       order by f.territoryname";

$result1 = mysqli_query($conn,$sql1);

$pendapatan = array();

while ($row = mysqli_fetch_array($result1)) {
    array_push($pendapatan,array(
        "pendapatan"=>$row['pendapatan'],
        "bulan" => $row['bulan'],
        "kategori" => $row['kategori']
    ));
}

//var_dump($pendapatan[1]);

// var_dump($pendapatan[0]['pendapatan']);

$arrayLength = count($pendapatan);

$a = 0;
$i = 0;
$hasil = array();

$hasil = array();
    foreach ($pendapatan as $dapat) {
array_push($hasil,array(
                "persen" => $dapat["pendapatan"],
                "bulan" => $dapat['bulan'],
                "kategori" => $dapat["kategori"]
            ));
        }


$json2 = json_encode($hasil);
//while ($i < $arrayLength2)
//{
//    while ($a < 4) {
//        if ($pembagi[$i]['kategori']==$pendapatan[$a]['kategori']){
//        $pembagi = floatval($pembagi[$i]['pembagi']);
//        $pendapatan =  floatval($pendapatan[$a]['pendapatan']);
//        $hasilHitung = $pendapatan/$pembagi*100;
//        echo $hasilHitung;
//        $a++;
//        }
//    }
//    $i++;
//}

//$data = json_encode(array('result'=>$hasil), JSON_NUMERIC_CHECK);

?>